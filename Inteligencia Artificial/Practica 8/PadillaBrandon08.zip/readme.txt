Brandon Padilla Ruiz
312139805
Practica 08

Para correr la practica primero nos movemos a donde esta el archivo Factor.py, luego ejecutamos el siguiente comando:

1. python3 Factor.py

Al correr el archivo automaticamente se ejecutan las pruebas.


