Brandon Padilla Ruiz
312139805
Práctica 01

En general no tuve complicaciones al hacer la práctica.
