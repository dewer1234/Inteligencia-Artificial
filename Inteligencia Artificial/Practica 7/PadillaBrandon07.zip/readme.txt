Brandon Padilla Ruiz
312139805
Practica 07

Para correr la practica primero nos movemos a donde esta el archivo AlgoritmosGeneticos.java, luego ejecutamos los siguientes comandos:

1. javac AlgoritmosGeneticos.java
2. java AlgoritmosGeneticos

Se puede ejecutar con parámetros de la siguiente manera:

java AlgoritmosGeneticos tamTablero tamMuestra
	
si se ejecuta sin parámetros la muestra será de 50 y el tablero de 8.
