
Brandon Padilla Ruiz
312139805
Practica 05

Para correr la practica primero nos movemos a donde esta el archivo Perceptron.java, luego ejecutamos los siguientes comandos:

1. javac Perceptron.java
2. java Perceptron
