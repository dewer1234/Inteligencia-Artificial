import java.util.*;

public class Perceptron {
    double TAZA = 0.1;        //taza de aprendizaje
    Random rnd;               //Un generador de números aleatorios
    double umbral;            //Umbral para determinar la salida
    int [][] entrenamiento ;  //Conjunto de entrenamiento del Perceptrón
    double [] pesos;          //Pesos que irán mutando al aprender

    
    //Constructor del perceptron
    Perceptron( int [][] entrenamiento ){
	rnd = new Random();
	umbral = 0.5;
	pesos = new double [3];
	for(int i = 0;i<3;i++)
	    pesos[i] = 0;	       
	this.entrenamiento = entrenamiento;
    }
    
    /**
       Método que utiliza la función de activación del perceptrón y 
       actualiza los pesos correspondientes según la salida de la función 
       de activación, realizando así el aprendizaje, para una entrada dada
       @param entrada, un solo ejemplar del conjunto de entrenamiento       
    */     
    
    void activar_aprender(int [] entrada){
	double Yj = 0;
	//calcular la suma
	for(int i = 0 ;i<3;i++){
	    Yj = entrada[i] * pesos [i]; 
	}
	//restar el umbral
	Yj -= umbral;
	//y aplicar la función step
	if (Yj >= 0)
	    Yj = 1;
	else
	    Yj = 0;
	//calcular el error e(j) 
	double error = entrada[3] - Yj;
	//por último actualizmos los pesos
	for(int i = 0; i<3 ;i++)
	    pesos[i] += TAZA * error * entrada[i] ;		    
    }//activar_aprender

    /**
       Método activa todos los ejemplares del conjunto de entrenamiento,
       entrenando así al perceptrón
       @param veces, las veces que se recorre entero el conjunto de entrenamiento
    */ 
    
    void entrena(int veces){
	int i = 0;
	while(i<veces){	    
	    for(int[] entrada : entrenamiento)
		activar_aprender(entrada);
	    i++;
	    System.out.println("Los pesos tras iterar " + i + " veces son: ");
	    for(double p:pesos)
		System.out.println(p);			    
	}
	
    }

    /**
       Método que dada una cierta entrada responde según haya sido entrenado
       @param entrada, la entrada ques será respondida   
     */     
    
    int responde(int[] entrada){
	double Yj = 0;
	//calcular la suma
	for(int i = 0 ;i<3;i++){
	    Yj += entrada[i] * pesos [i]; 
	}
	//restar el umbral
	Yj -= umbral;
	//y aplicar la función step
	if (Yj >= 0)
	    return 1;
	return 0;	
    }
    
    
    public static void main(String [] args){
	//los cinco conjuntos de entrenamiento para el AND
	int [][] e1= {{0,0,0,0},
		      {1,1,1,1}};
	int [][] e2= {{0,0,0,0},
		      {0,0,1,0},
		      {0,1,0,0},
		      {0,1,1,0},
		      {1,0,0,0},
		      {1,0,1,0},
		      {1,1,0,0},
		      {1,1,1,1}};
	int [][] e3= {{0,0,0,0},
		      {0,0,1,0},
		      {0,1,1,0},
		      {1,1,0,0},
		      {1,1,1,1}};
	int [][] e4= {{0,0,0,0},
		      {0,0,1,0},
		      {0,1,0,0},
		      {1,1,0,0},
		      {1,1,1,1}};
	int [][] e5= {{0,0,0,0},
		      {0,0,1,0},
		      {0,1,0,0},
		      {0,1,1,0},
		      {1,0,0,0}};

	//Los cinco que son para el OR
	int [][] e6= {{0,0,0,0},
		      {1,1,1,1}};
	int [][] e7= {{0,0,0,0},
		      {0,0,1,1},
		      {0,1,0,1},
		      {0,1,1,1},
		      {1,0,0,1},
		      {1,0,1,1},
		      {1,1,0,1},
		      {1,1,1,1}};
	int [][] e8= {{0,0,0,0},
		      {0,0,1,1},
		      {0,1,0,1},
		      {0,1,1,1},
		      {1,1,0,1},
		      {1,1,1,1}};
	int [][] e9= {{0,0,0,0},
		      {0,1,1,1},
		      {1,0,0,1},
		      {1,1,0,1},
		      {1,1,1,1}};
	int [][] e10= {{0,0,0,0},
		      {0,0,1,1},
		      {1,1,0,1},
		      {1,1,1,1}};
	int [][][] opciones = {e1,e2,e3,e4,e5,e6,e7,e8,e9,e10};

	while(true){
	    try{		
		System.out.print("Hola usuario, ¿Cuál Perceptron usarás (1)AND ó (2)OR,(3)Salir?\n>> ");
		Scanner s = new Scanner(System.in); 
		int n = s.nextInt();
		if(n == 1)
		    n = 0;
		else if(n == 2)
		    n = 5;
		else if(n == 3)
		    break;
		else
		    throw(new Exception());
		System.out.println("Existen 5 conjuntos de entrenamiento para el perceptron");
		System.out.print("¿Cuál usarás 1,2,3,4 ó 5?\n>> ");
		int r = s.nextInt();
		if(r < 1 || r > 5)
		    throw(new Exception());
		n = n + r - 1;		
		Perceptron per = new Perceptron(opciones[n]);
		System.out.println("El conjunto de entrenamiento es el siguiente: ");
		for(int[] ejemplar: per.entrenamiento){
		    System.out.print("[");
		    for(int i : ejemplar)			
			System.out.print("" + i + " ");
		    System.out.println("]");
		}
		System.out.println("El umbral usado será  : " + per.umbral );
		System.out.println("Los pesos iniciales son: ");
		for(double p:per.pesos)
		    System.out.println(p);		

		per.entrena(2);		
		int[][] entradas = {{0,0,0},
				    {1,0,1},
				    {0,0,1},
				    {1,1,1}};

		System.out.println("\n\nPruebas del entrenamiento elegido: ");
		for(int[] ejemplar: entradas){
		    System.out.print("Entradas [");
		    for(int i : ejemplar)			
			System.out.print("" + i + " ");
		    System.out.println("]    Salida del Perceptrón :" + per.responde(ejemplar));
		}
				
	    }catch(Exception e){System.out.println("Opción inválida intenta de nuevo :( ");}
	}
    }
    
}
