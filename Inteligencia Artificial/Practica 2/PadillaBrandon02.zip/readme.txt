Brandon Padilla Ruiz
312139805
Práctica 02

Al final el número de nodos a partir de la profundidad 4 no era el mismo y no sabía a que se debía el problema.
